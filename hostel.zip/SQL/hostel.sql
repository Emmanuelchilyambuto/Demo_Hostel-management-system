-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2022 at 09:19 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updation_date` date NOT NULL,
  `location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `reg_date`, `updation_date`, `location`) VALUES
(2, 'luchi', 'emmanuelchilyambuto@gmail.com ', '4428', '2022-10-10 06:48:06', '0000-00-00', 'Chalala'),
(3, 'Elijah', 'emmanuelchilyambuto@gmail.com ', '1234', '2022-10-16 09:46:34', '0000-00-00', 'Chilenje'),
(4, 'Emmanuel ', 'emmanuelchilyambuto@gmail.com ', 'Emmanuel ', '2022-10-16 09:17:28', '0000-00-00', 'Kabangwe '),
(9, 'jane', 'jane@jane', 'jane', '2022-10-17 12:54:19', '0000-00-00', 'kabangwe'),
(10, 'Moses ', 'moses@gmail.com', 'moses', '2022-10-17 21:21:00', '0000-00-00', 'ibex'),
(11, 'joseph ', 'joseph@joseph ', 'joseph', '2022-10-17 22:25:28', '0000-00-00', 'kabwe'),
(12, 'Laravel', 'lara@lara', 'laravel ', '2022-10-18 14:58:29', '0000-00-00', 'minestone'),
(13, 'steve', 'steve@steve', 'steve', '2022-10-21 05:07:00', '0000-00-00', 'lstone');

-- --------------------------------------------------------

--
-- Table structure for table `adminlog`
--

CREATE TABLE `adminlog` (
  `id` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `logintime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cincome`
--

CREATE TABLE `cincome` (
  `id` int(100) NOT NULL,
  `no` int(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `room` varchar(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `location` varchar(101) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cincome`
--

INSERT INTO `cincome` (`id`, `no`, `fname`, `last_name`, `contact`, `room`, `fees`, `date`, `location`) VALUES
(3, 35, 'joshua', 'Bwalya', '968989004', ' lazi ', '800', '2022-10-31', 'Chilenje'),
(2, 39, 'Emmanuel', 'Bwalya', '976050704', ' Tecno ', '500', '2022-10-31', 'Chalala');

-- --------------------------------------------------------

--
-- Table structure for table `deleted`
--

CREATE TABLE `deleted` (
  `id` int(10) NOT NULL,
  `roomno` varchar(100) NOT NULL,
  `seater` int(11) NOT NULL,
  `location` varchar(100) NOT NULL,
  `feespm` int(11) NOT NULL,
  `stayfrom` date NOT NULL,
  `duration` int(11) NOT NULL,
  `regno` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `contactno` varchar(11) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `egycontactno` varchar(100) NOT NULL,
  `guardianName` varchar(111) NOT NULL,
  `guardianRelation` varchar(111) NOT NULL,
  `guardianContactno` varchar(111) NOT NULL,
  `pmntCity` varchar(111) NOT NULL,
  `comment` varchar(100) NOT NULL,
  `postingDate` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deleted`
--

INSERT INTO `deleted` (`id`, `roomno`, `seater`, `location`, `feespm`, `stayfrom`, `duration`, `regno`, `firstName`, `lastName`, `gender`, `contactno`, `emailid`, `egycontactno`, `guardianName`, `guardianRelation`, `guardianContactno`, `pmntCity`, `comment`, `postingDate`) VALUES
(3, 'china', 5, '', 500, '2020-08-01', 6, 1, 'Lewis', 'Luko', 'male', '1234567890', 'ak@gmail.com', '1236547890', 'ABC', 'XYZ', '98756320000', 'Rufunsa', 'Prostitution', '2022-10-16'),
(2, 'Chicago ', 2, '', 450, '0000-00-00', 0, 2, 'Emmanuel', 'Chilyambuto', 'male', '976050704', 'emmanuelchilyambuto@gmail.com', '968989004', 'mr Chilyambuto ', 'father ', '968989002', 'Lusaka', 'Theft', '2022-10-16'),
(2, 'Chicago ', 2, '', 450, '2022-10-12', 3, 10806129, 'Luyando ', 'Haachamba', 'female', '972768565', 'nassa19nasa@gmail.com', '968989004', 'mr doe', 'father ', '968989002', 'kabwe', 'good terms', '2022-10-18'),
(2, 'Chicago ', 2, '', 450, '2022-10-15', 3, 10806136, 'Ronah', 'namwila', 'female', '976050704', 'ssa19nasa@gmail.com', '968989004', 'mr chanda', 'father ', '968989002', 'Lusaka', 'Prostitution', '2022-10-18'),
(3, 'Ghana ', 2, '', 450, '2022-10-15', 0, 10806137, 'john', 'chanda', 'male', '976050704', 'dicksonmulalu21@gmail.com', '968989004', 'mr doe', 'father ', '968989002', 'Lusaka', 'bools', '2022-10-17'),
(10, ' Alaska ', 4, '', 450, '2022-10-18', 1, 10806148, 'Ronah', 'Chilyambuto', 'male', '972768565', 'dicksonmulalu21@gmail.com', '123456', 'mr chanda', 'father ', '123', 'Lusaka', 'good terms', '2022-10-18'),
(10, ' Florida ', 3, '', 567, '2022-10-18', 2, 10806151, 'sipiwe ', 'chikandiwa', 'male', '23', 'marketing.epc04@gmail.com', '2', 'mr chanda', 'father ', '4', 'kabwe', 'Theft', '2022-10-18'),
(11, ' Alabama  ', 2, '', 450, '2022-10-18', 1, 10806152, 'sarah', ' zulu', 'female', '9', 'zulu@zulu', '0', 'mr doe', 'father ', '0', 'Lusaka', 'good terms', '2022-10-18'),
(9, ' idaho ', 3, '', 567, '2019-10-23', 1, 10806154, 'North', 'carolina', 'male', '0', 'null@null', '0', 'null', 'null', '0', 'null', '', '2022-10-18'),
(2, ' matero ', 4, '', 450, '2022-10-18', 1, 10806156, 'Felita', 'Mutale', 'female', '78', 'felita@felita', '111', 'mr doe', 'father ', '0', 'Lusaka', '', '2022-10-20'),
(12, ' Woodlands ', 3, '', 500, '2022-10-18', 5, 10806157, 'Yuzuru', 'Hanyu', 'male', '456', 'Yuzuru@hanyu', '679', 'Mr Kong hong', 'uncle', '598', 'Taiwan', '', '2022-10-19'),
(12, ' highridge ', 2, '', 900, '2022-10-18', 1, 10806158, 'Bambi', 'kesh', 'male', '0', 'null@null', '0', 'null', 'null', '0', 'null', 'good terms', '2022-10-18'),
(12, ' Woodlands ', 0, '', 500, '2022-10-18', 1, 10806159, 'joe', 'biscuit', 'male', '976050704', 'nassa19nasa@gmail.com', '111', 'mr doe', 'null', '123', 'Lusaka', '', '2022-10-19'),
(12, ' Woodlands ', 1, '', 500, '2022-10-19', 1, 10806160, 'Katie', 'Kassie ', 'female', '11112', 'nassa19nasa@gmail.com', '1234', 'Mr Kong hong', 'father ', '968989002', 'Lusaka', '', '2022-10-19'),
(12, ' Woodlands ', 1, '', 500, '2022-10-19', 1, 10806161, 'Deric ', 'Bwalya', 'male', '1111', 'emmanuelchilyambuto@gmail.com', '111', 'mr doe', 'father ', '567', 'Lusaka', '', '2022-10-19'),
(12, ' Woodlands ', 1, '', 500, '2022-10-19', 1, 10806162, 'Royce ', 'zulu', 'female', '1111', 'nassanasa@gmail.com', '968989001', 'Mr Kong hong', 'father ', '96898900', 'Lusaka', '', '2022-10-20'),
(12, ' Woodlands ', 1, '', 500, '2022-07-10', 1, 10806163, 'Dicky', 'kau', 'male', '97720304', 'dicksonmulalu21@gmail.com', '12345', 'mr doe', 'father ', '0', 'Lusaka', '', '2022-10-19'),
(12, ' Woodlands ', 1, '', 500, '2022-09-20', 1, 10806165, 'Alice ', 'chanda', 'female', '972768565', 'marketing.epc704@gmail.com', '123456', 'mr doe', 'father ', '567', 'Lusaka', '', '2022-10-20'),
(13, ' mongu ', 3, '', 500, '2022-06-28', 1, 10806168, 'Emmanuel', 'Chilyambuto', 'male', '976050704', 'emmanuelchilyambuto@gmail.com', '968989004', 'mr Chilyambuto ', 'father ', '968989002', 'Lusaka', '', '2022-10-21'),
(3, ' ndola ', 2, 'Chilenje', 444, '2022-10-29', 1, 10806171, 'luyando ', 'nyirongo', 'female', '968989004', 'marketing.epc04@gmail.com', '968989003', 'mr doe', 'father ', '598', 'Lusaka', '', '2022-10-30'),
(3, ' luchi', 3, 'Chilenje', 500, '2022-10-01', 0, 10806172, 'luchi', 'prince ', 'male', '111132', 'nassa19nasa@gmail.com', '1234', 'Mr Kong hong', 'uncle', '567', 'Lusaka', 'uchende', '2022-10-30'),
(3, ' lazi ', 1, 'Chilenje', 800, '2022-10-01', 0, 10806173, 'lazarous', 'Black', 'male', '86', 'dicksonmulalu21@gmail.com', '531', 'Mrs Hamududu', 'mother ', '524', 'mandanga', '', '2022-10-30');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(100) NOT NULL,
  `no` int(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `month` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `comment` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `no`, `date`, `month`, `description`, `price`, `comment`, `location`) VALUES
(4, 1, '2022-09-26', 'January ', 'Food', '1000', 'food', 'kabangwe '),
(3, 2, '2022-09-26', 'October', 'power', '20', 'power', ''),
(3, 3, '2022-09-27', 'February ', 'SALARIES', '200', 'NULL', ''),
(3, 4, '2022-09-27', 'APRIL', 'TV', '900', '', ''),
(3, 5, '2022-09-27', 'MARCH', 'AIRTIME', '40', '', ''),
(3, 6, '2022-09-27', 'MAY', 'FOOD', '300', '', ''),
(3, 7, '2022-09-29', 'October', 'Food', '500', 'food', 'kabangwe '),
(3, 8, '0000-00-00', '', 'Salary ', '500', '', ''),
(3, 9, '0000-00-00', '', 'housing', '450', 'housing', 'ibex'),
(3, 10, '2022-10-29', '', 'TRT', '400', 'trt', ''),
(3, 11, '2022-10-30', '', 'water', '200', 'water', 'kabangwe '),
(3, 12, '2022-10-30', '', 'lew', '300', 'Prostitution', 'Chilenje'),
(3, 13, '2022-10-30', '', 'Mechanics', '500', 'Stove', 'Chilenje'),
(3, 14, '2022-10-30', '', 'plumber', '200', 'Water pipe', 'Chilenje'),
(3, 15, '2022-10-30', '', 'Electrician', '300', 'Female Kitchen stove repair', 'Chilenje'),
(3, 23, '2021-10-30', '', 'food', '2000', 'good terms', 'Chilenje'),
(3, 24, '2022-10-30', '', 'Electricity', '300', 'Montly', 'Chilenje'),
(3, 25, '2022-10-30', '', 'Electrician', '300', 'Kitchen stove', 'Chilenje'),
(3, 27, '2022-10-31', '', 'food', '300', '', 'Chilenje'),
(3, 28, '2022-10-31', '', 'Electrician', '300', '', 'Chilenje'),
(3, 30, '2022-10-31', '', 'power', '700', 'monthly ', 'Chilenje'),
(3, 31, '2022-10-31', '', 'food', '500', '', 'Chilenje'),
(3, 32, '2022-10-31', '', 'Electrician', '300', 'Breaker fixing', 'Chilenje'),
(3, 33, '2022-10-31', '', 'Electrician', '300', '', 'Chilenje'),
(2, 34, '2022-10-31', '', 'food', '300', '', 'Chalala');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(10) NOT NULL,
  `no` int(10) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `description` varchar(235) NOT NULL,
  `price` varchar(225) NOT NULL,
  `comment` varchar(155) NOT NULL,
  `location` varchar(101) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `id` int(100) NOT NULL,
  `no` int(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `room` varchar(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`id`, `no`, `fname`, `last_name`, `contact`, `room`, `fees`, `date`, `location`) VALUES
(3, 3, 'Emmanuel ', 'Chilyambuto ', '1234', 'japan', '500', '2022-10-31', 'chilenje '),
(3, 4, 'luchi', 'jacob', '124', 'india', '500', '2022-10-31', 'chilenje '),
(3, 5, 'jane', 'doe', '453', 'india', '550', '2022-10-31', 'chilenje '),
(3, 7, 'prudence', 'Chilyambuto', '976050705', 'kabwe', '567', '2022-10-31', 'kabangwe '),
(3, 8, 'luyando ', 'Chilyambuto', '1111', 'japan', '444', '2022-10-31', 'Chilenje'),
(3, 9, 'Alice ', 'doe', '976050704', ' ndola ', '444', '2022-10-31', 'Chilenje'),
(3, 10, 'MILO', 'CHICHI', '976050704', ' Egypt  ', '444', '2022-10-31', 'Chilenje'),
(3, 11, 'Ronah', 'joe', '976050704', ' Lulu ', '1000', '2022-10-31', 'Chilenje'),
(3, 14, 'prudence', 'Chilyambuto', '976050705', 'kabwe', '567', '2022-10-30', 'kabangwe '),
(3, 15, 'luyando ', 'Chilyambuto', '1111', 'japan', '444', '2022-10-30', 'Chilenje'),
(3, 16, 'Alice ', 'doe', '976050704', ' ndola ', '444', '2022-10-30', 'Chilenje'),
(3, 17, 'MILO', 'CHICHI', '976050704', ' Egypt  ', '444', '2022-10-31', 'Chilenje'),
(3, 18, 'Ronah', 'joe', '976050704', ' Lulu ', '1000', '2022-10-31', 'Chilenje'),
(3, 21, 'Ron', 'do', '976050704', ' Emma ', '500', '2022-10-31', 'Chilenje'),
(3, 22, 'prudence', 'Chilyambuto', '976050705', 'kabwe', '567', '2022-10-31', 'kabangwe '),
(3, 24, 'Ali', 'kuah', '976050705', ' ndola ', '444', '2022-10-31', 'Chilenje'),
(3, 25, 'joshua', 'Bwalya', '968989004', ' lazi ', '800', '2022-10-31', 'Chilenje'),
(3, 26, 'prudence', 'Chilyambuto', '976050705', 'kabwe', '567', '2022-10-31', 'kabangwe '),
(3, 27, 'luyando ', 'Chilyambuto', '1111', 'japan', '444', '2022-10-31', 'Chilenje'),
(3, 28, 'Ronah', 'joe', '976050704', ' Lulu ', '1000', '2022-10-31', 'Chilenje'),
(3, 29, 'Ron', 'do', '976050704', ' Emma ', '500', '2022-10-31', 'Chilenje'),
(3, 30, 'janet', 'jane', '34', ' lele ', '750', '2022-10-31', 'Chilenje'),
(3, 31, 'Ron', 'do', '976050704', ' Emma ', '500', '2022-10-31', 'Chilenje'),
(3, 39, 'prudence', 'Chilyambuto', '976050705', 'kabwe', '567', '2022-10-31', 'kabangwe '),
(3, 40, 'luyando ', 'Chilyambuto', '1111', 'japan', '444', '2022-10-31', 'Chilenje'),
(3, 41, 'Alice ', 'doe', '976050704', ' ndola ', '444', '2022-10-31', 'Chilenje'),
(3, 42, 'MILO', 'CHICHI', '976050704', ' Egypt  ', '444', '2022-10-31', 'Chilenje'),
(3, 43, 'Ronah', 'joe', '976050704', ' Lulu ', '1000', '2022-10-31', 'Chilenje'),
(3, 44, 'Ron', 'do', '976050704', ' Emma ', '500', '2022-10-31', 'Chilenje'),
(3, 45, 'joshua', 'Bwalya', '968989004', ' lazi ', '800', '2022-10-31', 'Chilenje'),
(3, 46, 'Ali', 'kuah', '976050705', ' ndola ', '444', '2022-10-31', 'Chilenje'),
(3, 47, 'janet', 'jane', '34', ' lele ', '750', '2022-10-31', 'Chilenje'),
(3, 54, 'prudence', 'Chilyambuto', '976050705', 'kabwe', '567', '2022-10-31', 'kabangwe '),
(3, 55, 'prudence', 'Chilyambuto', '976050705', 'kabwe', '567', '2022-10-31', 'kabangwe '),
(2, 56, 'Deric', 'Bwalya', '977203047', 'kabwe', '567', '2022-10-31', 'kabangwe '),
(2, 57, 'Alice', 'Hamududu', '12', ' chowa ', '450', '2022-10-31', 'Chalala'),
(2, 58, 'luyando ', 'do', '9772030', 'Egypt ', '400', '2022-10-31', 'Chalala');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `email`, `contact`, `password`) VALUES
(1, 'admin', 'admin@gmail.com ', '1111', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(100) NOT NULL,
  `roomno` varchar(11) DEFAULT NULL,
  `seater` int(11) DEFAULT NULL,
  `location` varchar(100) NOT NULL,
  `feespm` int(11) DEFAULT NULL,
  `stayfrom` date DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `regno` int(11) NOT NULL,
  `firstName` varchar(500) DEFAULT NULL,
  `lastName` varchar(500) DEFAULT NULL,
  `gender` varchar(250) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `emailid` varchar(500) DEFAULT NULL,
  `egycontactno` bigint(11) DEFAULT NULL,
  `guardianName` varchar(500) DEFAULT NULL,
  `guardianRelation` varchar(500) DEFAULT NULL,
  `guardianContactno` bigint(11) DEFAULT NULL,
  `pmntCity` varchar(500) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `roomno`, `seater`, `location`, `feespm`, `stayfrom`, `duration`, `regno`, `firstName`, `lastName`, `gender`, `contactno`, `emailid`, `egycontactno`, `guardianName`, `guardianRelation`, `guardianContactno`, `pmntCity`, `postingDate`, `updationDate`) VALUES
(2, 'kabwe', 2, 'kabangwe ', 567, '2022-10-15', 1, 10806138, 'Deric', 'Bwalya', 'male', 977203047, 'marketing.epc@gmail.com', 1234, 'mr doe', 'father ', 567, 'Lusaka', '2022-10-15 21:58:17', NULL),
(3, 'kabwe', 2, 'kabangwe ', 567, '2022-10-16', 3, 10806140, 'prudence', 'Chilyambuto', 'female', 976050705, 'prudencechilyambuto@gmail.com', 111, 'mr Chilyambuto ', 'father ', 123, 'Lusaka', '2022-10-16 09:15:26', NULL),
(4, 'Burundi', 0, 'kabangwe ', 450, '2022-10-16', 3, 10806141, 'Emmanuel', 'Chilyambuto', 'male', 1111, 'nassa19nasa@gmail.com', 968989004, 'mr doe', 'father ', 968989002, 'Lusaka', '2022-12-16 10:20:30', NULL),
(1, ' Texas ', 1, 'kabangwe ', 444, '2022-10-17', 1, 10806142, 'Ronah', 'nyirongo', 'female', 977203047, 'nassa19nasa@gmail.com', 968989004, 'mr doe', 'father ', 968989002, 'Lusaka', '2022-10-17 11:28:27', NULL),
(1, 'Niger ', 2, '', 450, '2022-10-17', 2, 10806143, 'Ruth', 'chanda', 'female', 1111, 'emmanuelchilyambuto@gmail.com', 111, 'mr doe', 'father ', 567, 'Lusaka', '2022-10-17 12:16:15', NULL),
(1, ' Texas ', 1, '', 444, '2022-10-17', 2, 10806144, 'Emmanuel', 'Chilyambuto', 'male', 976050704, 'prudencechilyambuto@gmail.com', 123456, 'mr doe', 'father ', 968989002, 'Lusaka', '2022-10-17 12:20:15', NULL),
(3, 'japan', 2, 'Chilenje', 444, '2022-10-17', 1, 10806145, 'luyando ', 'Chilyambuto', 'female', 1111, 'prudencechilyambuto@gmail.com', 111, 'mr Chilyambuto ', 'father ', 968989002, 'Lusaka', '2022-10-17 12:42:57', NULL),
(9, ' kitwe ', 3, 'kabangwe', 444, '2022-10-17', 1, 10806146, 'Florence', 'Chilyambuto', 'male', 1111, 'prudencechilyambuto@gmail.com', 111, 'mr doe', 'father ', 968989002, 'Lusaka', '2022-10-17 14:41:10', NULL),
(10, ' Alaska ', 4, 'ibex', 450, '2022-10-18', 1, 10806149, 'Precious', 'mbusopo', 'female', 976050705, 'dicksonmulalu21@gmail.com', 968989004, 'mr doe', 'father ', 968989002, 'Lusaka', '2022-10-17 22:13:00', NULL),
(10, ' Arizon ', 3, 'ibex', 450, '2022-10-18', 6, 10806150, 'Ronah', 'namwila', 'female', 976050704, 'prudencechilyambuto@gmail.com', 968989004, 'mr doe', 'father ', 968989002, 'Lusaka', '2022-10-17 22:13:38', NULL),
(11, ' Nebraska ', 2, 'kabwe', 567, '2022-10-18', 7, 10806153, 'charity', 'miyoba', 'female', 0, 'null@null', 0, 'null', 'null', 0, 'null', '2022-02-17 23:33:32', NULL),
(2, ' chowa ', 4, 'Chalala', 450, '2022-10-18', 1, 10806155, 'Alice', 'Hamududu', 'female', 12, 'Hamududu@gmail.com', 12349, 'Mrs Hamududu', 'mother ', 123, 'monze', '2022-10-18 05:22:24', NULL),
(12, ' highridge ', 2, 'minestone', 900, '2022-08-02', 1, 10806164, 'Steve', 'harvey', 'male', 976050704, 'marketing.epc704@gmail.com', 1234, 'mr doe', 'father ', 4, 'Lusaka', '2022-10-19 15:10:38', NULL),
(12, ' Woodlands ', 1, 'minestone', 500, '2022-08-03', 1, 10806166, 'luyando ', 'Bwalya', 'male', 976050704, 'nassa19nasa@gmail.com', 123456, 'mr doe', 'null', 4, 'Lusaka', '2022-10-20 06:16:19', NULL),
(2, 'Egypt ', 4, 'Chalala', 400, '2022-07-13', 1, 10806167, 'luyando ', 'do', 'female', 9772030, 'mating.epc704@gmail.com', 1234987, 'unfortunately ', 'father ', 59864, 'Lusaka', '2022-10-20 15:01:57', NULL),
(3, ' ndola ', 2, 'Chilenje', 444, '2022-09-26', 4, 10806169, 'Alice ', 'doe', 'female', 976050704, 'nassa19nasa@gmail.com', 968989004, 'null', 'mother ', 598, 'Lusaka', '2022-10-26 14:04:19', NULL),
(3, ' Egypt  ', 4, 'Chilenje', 444, '2022-10-21', 2, 10806170, 'MILO', 'CHICHI', 'male', 976050704, 'nassa19nasa@gmail.com', 968989004, 'mr doe', 'father ', 4, 'Lusaka', '2022-10-27 13:47:10', NULL),
(3, ' Lulu ', 1, 'Chilenje', 1000, '2022-10-01', NULL, 10806174, 'Ronah', 'joe', 'female', 976050704, 'prudencechilyambuto@gmail.com', 0, 'Mrs Hamududu', 'null', 598, 'Lusaka', '2022-10-30 16:51:59', NULL),
(3, ' Emma ', 1, 'Chilenje', 500, '2022-10-31', NULL, 10806175, 'Ron', 'do', 'female', 976050704, 'prudencechilyambuto@gmail.com', 968989003, 'mr chanda', 'father ', 123, 'Lusaka', '2022-10-31 04:50:18', NULL),
(3, ' lazi ', 1, 'Chilenje', 800, '2022-10-31', NULL, 10806176, 'joshua', 'Bwalya', 'male', 968989004, 'marketing.epc704@gmail.com', 1234, 'Mr Kong hong', 'father ', 598, 'Lusaka', '2022-10-31 05:05:40', NULL),
(3, ' ndola ', 2, 'Chilenje', 444, '2022-10-31', NULL, 10806177, 'Ali', 'kuah', 'male', 976050705, 'emmanuelchilyambuto@gmail.com', 123456, 'Mr Kong hong', 'father ', 567, 'Lusaka', '2022-10-31 05:07:30', NULL),
(3, ' lele ', 4, 'Chilenje', 750, '2022-10-31', NULL, 10806178, 'janet', 'jane', 'female', 34, 'emmanuelchilyambuto@gmail.com', 1114, 'Mrs Hamududuf', 'mother ', 444, 'Lusaka', '2022-10-31 06:12:33', NULL),
(2, ' Tecno ', 2, 'Chalala', 500, '2022-10-31', NULL, 10806179, 'Emmanuel', 'Bwalya', 'male', 976050704, 'nassa19nasa@gmail.com', 968989004, 'mr doe', 'father ', 4, 'Lusaka', '2022-10-31 08:07:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(10) NOT NULL,
  `room_no` varchar(11) CHARACTER SET utf8mb4 NOT NULL,
  `seater` int(11) DEFAULT NULL,
  `fees` int(11) DEFAULT NULL,
  `location` varchar(100) NOT NULL,
  `posting_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_no`, `seater`, `fees`, `location`, `posting_date`) VALUES
(12, ' AB ', 2, 750, 'minestone', '2022-10-20 06:23:42'),
(11, ' Alabama  ', 2, 450, 'kabwe', '2022-10-17 22:26:48'),
(10, ' Alaska ', 4, 450, 'ibex', '2022-10-17 22:08:12'),
(10, ' Arizon ', 3, 450, 'ibex', '2022-10-17 22:07:45'),
(2, ' chowa ', 4, 450, 'Chalala', '2022-10-18 05:19:58'),
(3, ' Egypt  ', 4, 444, 'kabangwe', '2022-10-17 10:22:39'),
(3, ' Emma ', 1, 500, 'Chilenje', '2022-10-31 04:47:01'),
(10, ' Florida ', 3, 567, 'ibex', '2022-10-17 22:06:51'),
(12, ' highridge ', 2, 900, 'minestone', '2022-10-18 15:12:11'),
(10, ' Huawei  ', 3, 567, 'ibex', '2022-10-17 22:06:21'),
(9, ' idaho ', 3, 567, 'kabangwe', '2022-10-17 22:46:33'),
(10, ' Indiana ', 1, 450, 'ibex', '2022-10-17 22:08:33'),
(4, ' kabwe ', 1, 444, 'kabangwe', '2022-10-17 10:17:40'),
(2, ' katondo ', 2, 750, 'Chalala', '2022-10-17 23:45:33'),
(9, ' kitwe ', 3, 444, '', '2022-10-17 12:55:09'),
(3, ' lazi ', 1, 800, 'Chilenje', '2022-10-30 16:31:31'),
(3, ' lele ', 4, 750, 'Chilenje', '2022-10-31 06:11:42'),
(3, ' luchi', 3, 500, 'Chilenje', '2022-10-30 16:15:47'),
(3, ' Lulu ', 1, 1000, 'Chilenje', '2022-10-30 16:51:12'),
(4, ' Lusaka  ', 1, 444, 'kabangwe', '2022-10-17 10:17:15'),
(11, ' Maryland  ', 4, 450, 'kabwe', '2022-10-17 22:27:50'),
(2, ' matero ', 4, 450, 'Chalala', '2022-10-18 14:48:10'),
(13, ' mongu ', 3, 500, 'lstone', '2022-10-21 05:08:08'),
(3, ' ndola ', 2, 444, 'kabangwe', '2022-10-17 10:20:25'),
(11, ' Nebraska ', 2, 567, 'kabwe', '2022-10-17 22:27:08'),
(11, ' New jersy ', 1, 750, 'kabwe', '2022-10-17 22:27:25'),
(10, ' new mexico', 1, 567, 'ibex', '2022-10-17 22:03:25'),
(2, ' Tecno ', 2, 500, 'Chalala', '2022-10-31 08:05:07'),
(1, ' Texas ', 1, 444, 'kabangwe', '2022-10-17 10:29:19'),
(10, ' uta ', 1, 500, 'ibex', '2022-10-17 22:05:39'),
(10, ' Washington', 2, 450, 'ibex', '2022-10-17 22:07:27'),
(11, ' Wisconsin ', 2, 567, 'kabwe', '2022-10-17 22:28:07'),
(12, ' Woodlands ', 1, 500, 'minestone', '2022-10-18 15:10:08'),
(10, ' wyoming ', 2, 567, 'ibex', '2022-10-17 22:06:04'),
(13, ' xyt ', 4, 750, 'lstone', '2022-10-21 07:18:59'),
(12, ' xyz ', 2, 500, 'minestone', '2022-10-19 15:17:23'),
(2, 'ABCD', 4, 22, 'kabangwe', '2022-10-15 17:04:39'),
(4, 'Burundi', 4, 450, 'kabangwe', '2022-10-16 09:19:02'),
(2, 'Chicago ', 2, 450, 'kabangwe', '0000-00-00 00:00:00'),
(2, 'Egypt ', 4, 400, 'kabangwe', '2022-10-10 13:35:36'),
(2, 'Ethiopia ', 3, 500, 'kabangwe', '2022-10-10 13:35:36'),
(2, 'Ghana ', 2, 450, 'kabangwe', '2022-10-10 13:37:17'),
(3, 'Guinea Biss', 4, 500, 'kabangwe', '2022-10-10 13:37:17'),
(3, 'Ivory cost ', 3, 400, 'kabangwe', '2022-10-10 13:38:35'),
(3, 'japan', 2, 444, 'kabangwe', '2022-10-15 12:21:58'),
(3, 'kabwe', 2, 567, 'kabangwe', '2022-10-15 21:56:33'),
(2, 'Lusaka ', 2, 750, 'kabangwe', '2022-10-16 09:04:38'),
(3, 'Morocco ', 3, 500, 'kabangwe', '2022-10-10 13:38:35'),
(1, 'Niger ', 2, 450, 'kabangwe', '2022-10-10 13:40:04'),
(1, 'Nigeria ', 2, 500, 'kabangwe', '2022-10-10 13:40:04'),
(2, 'Texas', 2, 444, '', '2022-10-17 21:30:54');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `userIp` varbinary(16) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userId`, `userEmail`, `userIp`, `city`, `country`, `loginTime`) VALUES
(6, 3, '10806121', 0x3a3a31, '', '', '2020-07-20 14:56:45'),
(7, 3, 'test@gmail.com', 0x3a3a31, '', '', '2022-10-08 12:57:38'),
(8, 3, 'test@gmail.com', 0x3a3a31, '', '', '2022-10-10 06:37:23'),
(9, 3, 'test@gmail.com', 0x3a3a31, '', '', '2022-10-10 06:41:47'),
(10, 2, '', 0x3a3a31, '', '', '2022-10-16 07:23:15'),
(11, 3, '', 0x3a3a31, '', '', '2022-10-16 09:08:40'),
(12, 4, '', 0x3a3a31, '', '', '2022-10-16 09:18:07'),
(13, 3, '', 0x3a3a31, '', '', '2022-10-16 09:42:54'),
(14, 4, '', 0x3a3a31, '', '', '2022-10-16 09:44:16'),
(15, 3, '', 0x3a3a31, '', '', '2022-10-16 09:44:44'),
(16, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-16 09:48:23'),
(17, 1, 'anuj.lpu1@gmail.com', 0x3a3a31, '', '', '2022-10-16 09:49:55'),
(18, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-16 09:52:18'),
(19, 1, 'anuj.lpu1@gmail.com', 0x3a3a31, '', '', '2022-10-16 09:54:44'),
(20, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-16 10:02:31'),
(21, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-16 10:02:57'),
(22, 4, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-16 10:03:49'),
(23, 4, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 10:17:01'),
(24, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 10:18:58'),
(25, 1, 'anuj.lpu1@gmail.com', 0x3a3a31, '', '', '2022-10-17 10:28:50'),
(26, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 12:41:41'),
(27, 9, 'jane@jane', 0x3a3a31, '', '', '2022-10-17 12:54:43'),
(28, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 15:32:29'),
(29, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 15:38:19'),
(30, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 17:06:35'),
(31, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 17:06:36'),
(32, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 17:07:01'),
(33, 0, '', 0x3a3a31, '', '', '2022-10-17 17:54:12'),
(34, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 18:07:08'),
(35, 0, '', 0x3a3a31, '', '', '2022-10-17 18:54:49'),
(36, 0, '', 0x3a3a31, '', '', '2022-10-17 19:07:20'),
(37, 0, '', 0x3a3a31, '', '', '2022-10-17 19:08:15'),
(38, 0, '', 0x3a3a31, '', '', '2022-10-17 19:09:48'),
(39, 0, '', 0x3a3a31, '', '', '2022-10-17 19:21:46'),
(40, 0, '', 0x3a3a31, '', '', '2022-10-17 19:33:08'),
(41, 0, '', 0x3a3a31, '', '', '2022-10-17 19:35:43'),
(42, 0, '', 0x3a3a31, '', '', '2022-10-17 20:58:32'),
(43, 10, 'moses@gmail.com', 0x3a3a31, '', '', '2022-10-17 21:21:38'),
(44, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 21:28:18'),
(45, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 21:32:31'),
(46, 10, 'moses@gmail.com', 0x3a3a31, '', '', '2022-10-17 21:32:49'),
(47, 0, '', 0x3a3a31, '', '', '2022-10-17 22:16:46'),
(48, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 22:20:27'),
(49, 11, 'joseph@joseph ', 0x3a3a31, '', '', '2022-10-17 22:25:59'),
(50, 0, '', 0x3a3a31, '', '', '2022-10-17 22:45:37'),
(51, 9, 'jane@jane', 0x3a3a31, '', '', '2022-10-17 22:45:56'),
(52, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-17 23:44:03'),
(53, 0, '', 0x3a3a31, '', '', '2022-10-17 23:47:42'),
(54, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-18 05:19:40'),
(55, 0, '', 0x3a3a31, '', '', '2022-10-18 06:11:26'),
(56, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-18 06:16:05'),
(57, 0, '', 0x3a3a31, '', '', '2022-10-18 06:17:24'),
(58, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-18 06:25:26'),
(59, 10, 'moses@gmail.com', 0x3a3a31, '', '', '2022-10-18 06:27:00'),
(60, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-18 14:41:12'),
(61, 0, '', 0x3a3a31, '', '', '2022-10-18 14:54:00'),
(62, 12, 'lara@lara', 0x3a3a31, '', '', '2022-10-18 15:00:24'),
(63, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-20 14:13:40'),
(64, 13, 'steve@steve', 0x3a3a31, '', '', '2022-10-21 05:07:28'),
(65, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-26 12:42:07'),
(66, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-29 10:27:34'),
(67, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-30 13:57:54'),
(68, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-30 13:58:46'),
(69, 3, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-30 15:30:23'),
(70, 2, 'emmanuelchilyambuto@gmail.com ', 0x3a3a31, '', '', '2022-10-31 07:59:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cincome`
--
ALTER TABLE `cincome`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `deleted`
--
ALTER TABLE `deleted`
  ADD PRIMARY KEY (`regno`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`regno`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_no`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `cincome`
--
ALTER TABLE `cincome`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `no` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `income`
--
ALTER TABLE `income`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `regno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10806180;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
