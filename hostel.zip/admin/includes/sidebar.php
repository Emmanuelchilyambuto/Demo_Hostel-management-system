<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard1.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
					
				</li>
					<li><a href="#"><i class="fa fa-desktop"></i> Rooms</a>
					<ul>
					
						<li><a href="manage-rooms1.php">Manage Rooms</a></li>
					</ul>
				</li>
				<li><a href="#"><i class="fa fa-desktop"></i>Students</a>
				<ul>
				
				<li><a href="manage-students1.php"><i class="fa fa-users"></i>Manage Students</a></li>
				<li><a href="deleted1.php"><i class="fa fa-users"></i>View former Student </a></li>
				</ul>
				
			
			
		</nav>